- `sbr_gumruk` tablosunda `input`  degeri `ad` veya `edikod` alanlari arasindan arama yapilir. `ad` alanina gore siralanarak listelenir.
- `input` degeri gonderilmezse databaseden `500` data seklinde donus yapar.
- Ornek Request:
```
sbrGumruks (input: "S"){
	ad
	edikod
}
```